public class Digit {

    private int[][] imageValues;
    private int label;

    public Digit() {
        this.imageValues = new int[28][28];
    }

    public void setOne(int row, int column)
    {
        imageValues[row][column] = 1;
    }

    public void setZero(int row, int column)
    {
        imageValues[row][column] = 0;
    }

    public int getCharAt(int row, int column) {
        return this.getImageValues()[row][column];
    }

    public int[][] getImageValues() {
        return imageValues;
    }

    public int getLabel() {
        return label;
    }

    public void setLabel(int label) {
        this.label = label;
    }

    public void displayInfo()
    {
        for(int i = 0; i < imageValues.length; i++)
        {
            for(int j = 0; j < imageValues[0].length; j++)
            {
                if(imageValues[i][j] == 0)
                    System.out.print(" ");
                else
                    System.out.print("#");
            }
            System.out.println();
        }
    }
}
