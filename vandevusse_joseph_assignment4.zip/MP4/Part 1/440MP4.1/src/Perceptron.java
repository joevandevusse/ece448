import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Perceptron {
    private ArrayList<Digit> trainingImages;
    private ArrayList<Digit> testingImages;
    private double[] priors;
    private double[] counts;
    private Map<Integer, double[][]> weightVectors;
    private Map<Digit, Integer> trainingPredictions;
    private Map<Digit, Integer> testPredictions;
    private double[][] confusionMatrix;
    private ArrayList<Double> oddsRatiosArray;
    private double[] lowProbabilities;
    private double[] highProbabilities;
    public ArrayList<Digit> bestImages;
    public ArrayList<Digit> worstImages;
    public double[] probabilities;

    public Perceptron() {
        trainingImages = new ArrayList<>();
        testingImages = new ArrayList<>();
        priors = new double[10];
        counts = new double[10];
        weightVectors = new HashMap<>();
        trainingPredictions = new HashMap<>();
        testPredictions = new HashMap<>();
        confusionMatrix = new double[10][10];
        oddsRatiosArray = new ArrayList<>();
        probabilities = new double[1000];
        for (int i = 0; i < 1000; i++) {
            probabilities[i] = 0;
        }
    }

    public void setTrainingImages(ArrayList<Digit> trainingImages) {
        this.trainingImages = trainingImages;
    }

    public void setTestingImages(ArrayList<Digit> testingImages) {
        this.testingImages = testingImages;
    }

    public double[] getPriors() {
        return priors;
    }

    public void setPriors(double[] priors) {
        this.priors = priors;
    }

    public double[] getCounts() {
        return counts;
    }

    public void setCounts(double[] counts) {
        this.counts = counts;
    }

    public Map<Integer, double[][]> getWeightVectors() {
        return weightVectors;
    }

    public void setWeightVectors(Map<Integer, double[][]> weightVectors) {
        this.weightVectors = weightVectors;
    }

    public Map<Digit, Integer> getTrainingPredictions() {
        return trainingPredictions;
    }

    public void setTrainingPredictions(Map<Digit, Integer> trainingPredictions) {
        this.trainingPredictions = trainingPredictions;
    }

    public Map<Digit, Integer> getTestPredictions() {
        return testPredictions;
    }

    public void setTestPredictions(Map<Digit, Integer> testPredictions) {
        this.testPredictions = testPredictions;
    }

    public double[][] getConfusionMatrix() {
        return confusionMatrix;
    }

    public void setConfusionMatrix(double[][] confusionMatrix) {
        this.confusionMatrix = confusionMatrix;
    }

    public ArrayList<Double> getOddsRatiosArray() {
        return oddsRatiosArray;
    }

    public void setOddsRatiosArray(ArrayList<Double> oddsRatiosArray) {
        this.oddsRatiosArray = oddsRatiosArray;
    }

    public double[] getLowProbabilities() {
        return lowProbabilities;
    }

    public void setLowProbabilities(double[] lowProbabilities) {
        this.lowProbabilities = lowProbabilities;
    }

    public double[] getHighProbabilities() {
        return highProbabilities;
    }

    public void setHighProbabilities(double[] highProbabilities) {
        this.highProbabilities = highProbabilities;
    }

    public ArrayList<Digit> getBestImages() {
        return bestImages;
    }

    public void setBestImages(ArrayList<Digit> bestImages) {
        this.bestImages = bestImages;
    }

    public ArrayList<Digit> getWorstImages() {
        return worstImages;
    }

    public void setWorstImages(ArrayList<Digit> worstImages) {
        this.worstImages = worstImages;
    }

    public ArrayList<Digit> getTrainingImages() {
        return trainingImages;
    }

    public ArrayList<Digit> getTestingImages() {
        return testingImages;
    }

    public void initializeWeights(boolean rand) {
        for (int i = 0; i < 10; i++) {
            double[][] initialDouble = new double[28][28];
            for (int n = 0; n < 28; n++) {
                for (int m = 0; m < 28; m++) {
                    initialDouble[n][m] = 0;
                }
            }
            weightVectors.put(i, initialDouble);
            for (int j = 0; j < 28; j++) {
                for (int k = 0; k < 28; k++) {
                    if (rand)
                        weightVectors.get(i)[j][k] = Math.random();
                    else
                        weightVectors.get(i)[j][k] = 0;
                }
            }
        }
    }

    public void printConfusionMatrix() {
        int[] rowSums = new int[10];
        for (int i = 0; i < 10; i++) {
            rowSums[i] = 0;
            for (int j = 0; j < 10; j++) {
                confusionMatrix[i][j] = 0;
            }
        }
        for (int i = 0; i < testPredictions.size(); i++) {
            int labelValue = testingImages.get(i).getLabel();
            int predictedValue = testPredictions.get(testingImages.get(i));
            confusionMatrix[labelValue][predictedValue]++;
            rowSums[labelValue]++;
        }
        System.out.println("The confusion matrix is as follows. ");
        System.out.println("Rows correspond to the label value. ");
        System.out.println("Columns are the predicted values");
        System.out.println("The diagonal represent correct classifications");
        for (int i = 0; i < 10; i++) {
            System.out.println();
            System.out.println();
            for (int j = 0; j < 10; j++) {
                String conf = String.format("%.3g", confusionMatrix[i][j] / rowSums[i]);
                System.out.print(conf + "   ");
                confusionMatrix[i][j] = confusionMatrix[i][j] / rowSums[i];
                if (i != j)
                    oddsRatiosArray.add(confusionMatrix[i][j]);
            }
        }
        System.out.println();
        for (int i = 0; i < 10; i++) {
            System.out.println("Correct rate of classification with the best smoother for digit " + i + " is " + String.format("%.3g", confusionMatrix[i][i]));
        }
    }

    //standard dot product
    public double dotProduct(int[][] firstMatrix, double[][] secondMatrix) {
        double prod = 0;
        for (int i = 0; i < 28; i++) {
            for (int j = 0; j < 28; j++) {
                prod += firstMatrix[i][j] * secondMatrix[i][j];
            }
        }
        return prod;
    }


    public void readAndSetLabels(String filename, boolean training) throws FileNotFoundException {
        int numDigits;
        if (training)
            numDigits = 5000;
        else
            numDigits = 1000;
        Scanner inFile = new Scanner(new File(filename));
        for (int i = 0; i < numDigits; i++) {
            String label = inFile.nextLine();
            if (training)
                trainingImages.get(i).setLabel(Integer.parseInt(label));
            else
                testingImages.get(i).setLabel(Integer.parseInt(label));
        }
    }

    public void readAndSetDigits(String fileName, boolean training) throws FileNotFoundException {
        Scanner fileScan = new Scanner(new File(fileName));
        int numDigits;
        if (training)
            numDigits = 5000;
        else
            numDigits = 1000;
        for (int i = 0; i < numDigits; i++) {
            Digit currDigit = new Digit();
            for (int j = 0; j < 28; j++) {
                String line = fileScan.nextLine();
                for (int k = 0; k < line.length(); k++) {
                    if (line.charAt(k) != ' ')
                        currDigit.setOne(j, k);
                }
            }
            if (training)
                trainingImages.add(currDigit);
            else {
                testingImages.add(currDigit);
            }
        }
    }
    public void trainModel(int epochs, int bias, double learningRate) {
        for (int i = 0; i < epochs; i++) {
            calculateOneEpochTraining(i, epochs, bias, learningRate);
            double accuracy = calculateTrainingSetAccuracyForEpoch();
            System.out.println("Training accuracy after " + (i + 1) + " epochs is " + accuracy);
        }
    }

    public void calculateOneEpochTraining(int currEpoch, int totalEpochs,int bias, double learningRate) {
        //passes through the training images once, attempting to label them
        for (int i = 0; i < 5000; i++) {
            double highestDotProduct = -10000000;
            int indexOfHighestDot = -1;
            for (int j = 0; j < 10; j++) {
                double currDotProd = dotProduct(trainingImages.get(i).getImageValues(), weightVectors.get(j));
                if (currDotProd > highestDotProduct) {
                    highestDotProduct = currDotProd;
                    indexOfHighestDot = j;
                }
            }
            //got the correct label
            if (trainingImages.get(i).getLabel() == indexOfHighestDot) {
                trainingPredictions.put(trainingImages.get(i), indexOfHighestDot);
            } else {
                //the label was wrong so we correct the weightVector
                //this is where you modify the weight vector with additional things like learning rate and bias
                trainingPredictions.put(trainingImages.get(i), indexOfHighestDot);
                for (int k = 0; k < 28; k++) {
                    for (int m = 0; m < 28; m++) {
                        weightVectors.get(trainingImages.get(i).getLabel())[k][m] += 1/(1+Math.exp(currEpoch * 2))*trainingImages.get(i).getImageValues()[k][m] + bias;
                        weightVectors.get(indexOfHighestDot)[k][m] -= 1/(1+Math.exp(currEpoch * 2))*trainingImages.get(i).getImageValues()[k][m]+bias;
                    }
                }
            }
        }
    }

    //goes through trainingImages and trainingPredictions and compares their values returning a double of % accuracy
    public double calculateTrainingSetAccuracyForEpoch() {
        double correct = 0;
        for (int i = 0; i < 5000; i++) {
            if (trainingPredictions.get(trainingImages.get(i)) == trainingImages.get(i).getLabel()) {
                correct++;
            }
        }
        return correct / 5000;
    }

    public double calculateTestSetAccuracy() {
        double correct = 0;
        for (int i = 0; i < 1000; i++) {
            if (testPredictions.get(testingImages.get(i)) == testingImages.get(i).getLabel()) {
                correct++;
            }
        }
        return correct / 1000;
    }

    public void calculateOneEpochTest(int bias, double learningRate) {
        //passes through the training images once, attempting to label them
        for (int i = 0; i < 1000; i++) {
            double highestDotProduct = -10000000;
            int indexOfHighestDot = -1;
            for (int j = 0; j < 10; j++) {
                double currDotProd = dotProduct(testingImages.get(i).getImageValues(), weightVectors.get(j));
                if (currDotProd > highestDotProduct) {
                    highestDotProduct = currDotProd;
                    indexOfHighestDot = j;
                }
            }
            testPredictions.put(testingImages.get(i), indexOfHighestDot);
        }
    }



    public static void main(String[] args) throws FileNotFoundException {
        Perceptron perceptron = new Perceptron();
        perceptron.readAndSetDigits("trainingimages", true);
        perceptron.readAndSetLabels("traininglabels", true);
        perceptron.readAndSetDigits("testimages", false);
        perceptron.readAndSetLabels("testlabels", false);
        perceptron.initializeWeights(true);
        perceptron.trainModel(10, 0, 1);
        perceptron.calculateOneEpochTest(0,0);
        perceptron.printConfusionMatrix();
        System.out.println("Test set accuracy was " + perceptron.calculateTestSetAccuracy());
        System.out.println("Training set accuracy was " + perceptron. calculateTrainingSetAccuracyForEpoch());
    }
}