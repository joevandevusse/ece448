import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Collections;

public class KNearestNeighbors {
    private ArrayList<Digit> trainingImages;
    private ArrayList<Digit> testingImages;
    private double[] priors;
    private double[] counts;
    private Map<Digit, Integer> trainingPredictions;
    private Map<Digit, Integer> testPredictions;
    private double[][] confusionMatrix;
    private ArrayList<Double> oddsRatiosArray;

    public KNearestNeighbors() {
        trainingImages = new ArrayList<>();
        testingImages = new ArrayList<>();
        trainingPredictions = new HashMap<>();
        testPredictions = new HashMap<>();
        confusionMatrix = new double[10][10];
        oddsRatiosArray = new ArrayList<>();
    }

    public void setTrainingImages(ArrayList<Digit> trainingImages) {
        this.trainingImages = trainingImages;
    }

    public void setTestingImages(ArrayList<Digit> testingImages) {
        this.testingImages = testingImages;
    }

    public double[] getPriors() {
        return priors;
    }

    public void setPriors(double[] priors) {
        this.priors = priors;
    }

    public double[] getCounts() {
        return counts;
    }

    public void setCounts(double[] counts) {
        this.counts = counts;
    }

    public Map<Digit, Integer> getTrainingPredictions() {
        return trainingPredictions;
    }

    public void setTrainingPredictions(Map<Digit, Integer> trainingPredictions) {
        this.trainingPredictions = trainingPredictions;
    }

    public Map<Digit, Integer> getTestPredictions() {
        return testPredictions;
    }

    public void setTestPredictions(Map<Digit, Integer> testPredictions) {
        this.testPredictions = testPredictions;
    }

    public double[][] getConfusionMatrix() {
        return confusionMatrix;
    }

    public void setConfusionMatrix(double[][] confusionMatrix) {
        this.confusionMatrix = confusionMatrix;
    }


    public void setOddsRatiosArray(ArrayList<Double> oddsRatiosArray) {
        this.oddsRatiosArray = oddsRatiosArray;
    }

    public ArrayList<Digit> getTrainingImages() {
        return trainingImages;
    }

    public ArrayList<Digit> getTestingImages() {
        return testingImages;
    }

    public void calculatePriors() {
        for (int i = 0; i < trainingImages.size(); i++) {
            int position = trainingImages.get(i).getLabel();
            counts[position]++;
        }

        for (int i = 0; i < priors.length; i++)
            priors[i] = counts[i] / trainingImages.size();
    }

    public void printConfusionMatrix() {
        int[] rowSums = new int[10];
        for (int i = 0; i < 10; i++) {
            rowSums[i] = 0;
            for (int j = 0; j < 10; j++) {
                confusionMatrix[i][j] = 0;
            }
        }
        for (int i = 0; i < testPredictions.size(); i++) {
            int labelValue = testingImages.get(i).getLabel();
            int predictedValue = testPredictions.get(testingImages.get(i));
            confusionMatrix[labelValue][predictedValue]++;
            rowSums[labelValue]++;
        }
        System.out.println("The confusion matrix is as follows. ");
        System.out.println("Rows correspond to the label value. ");
        System.out.println("Columns are the predicted values");
        System.out.println("The diagonal represent correct classifications");
        for (int i = 0; i < 10; i++) {
            System.out.println();
            System.out.println();
            for (int j = 0; j < 10; j++) {
                String conf = String.format("%.3g", confusionMatrix[i][j] / rowSums[i]);
                System.out.print(conf + "   ");
                confusionMatrix[i][j] = confusionMatrix[i][j] / rowSums[i];
                if (i != j)
                    oddsRatiosArray.add(confusionMatrix[i][j]);
            }
        }
        System.out.println();
        for (int i = 0; i < 10; i++) {
            System.out.println("Correct rate of classification for digit " + i + " is " + String.format("%.3g", confusionMatrix[i][i]));
        }
    }

    //standard dot product
    public double dotProduct(int[][] firstMatrix, double[][] secondMatrix) {
        double prod = 0;
        for (int i = 0; i < 28; i++) {
            for (int j = 0; j < 28; j++) {
                prod += firstMatrix[i][j] * secondMatrix[i][j];
            }
        }
        return prod;
    }


    public void readAndSetLabels(String filename, boolean training) throws FileNotFoundException {
        int numDigits;
        if (training)
            numDigits = 5000;
        else
            numDigits = 1000;
        Scanner inFile = new Scanner(new File(filename));
        for (int i = 0; i < numDigits; i++) {
            String label = inFile.nextLine();
            if (training)
                trainingImages.get(i).setLabel(Integer.parseInt(label));
            else
                testingImages.get(i).setLabel(Integer.parseInt(label));
        }
    }

    public void readAndSetDigits(String fileName, boolean training) throws FileNotFoundException {
        Scanner fileScan = new Scanner(new File(fileName));
        int numDigits;
        if (training)
            numDigits = 5000;
        else
            numDigits = 1000;
        for (int i = 0; i < numDigits; i++) {
            Digit currDigit = new Digit();
            for (int j = 0; j < 28; j++) {
                String line = fileScan.nextLine();
                for (int k = 0; k < line.length(); k++) {
                    if (line.charAt(k) != ' ')
                        currDigit.setOne(j, k);
                }
            }
            if (training)
                trainingImages.add(currDigit);
            else {
                testingImages.add(currDigit);
            }
        }
    }

    //calculates the accuracy of the test set predictions versus the true labels
    public double calculateTestSetAccuracy() {
        double correct = 0;
        for (int i = 0; i < 1000; i++) {
            if (testPredictions.get(testingImages.get(i)) == testingImages.get(i).getLabel()) {
                correct++;
            }
        }
        System.out.println(correct/1000);
        return correct / 1000;
    }

    /**
     * Function that classifies the test Images
     * Loops over the entire training data set and finds the K-nearest neighbors via a similarity function
     * Counts the labels of the K-Nearest neighbors and sets the predicted value to the one with the highest count out of the k neighbors
     * @param kValue parameter that controls how many neighbors the algorithm uses
     */
    public void knnClassify(int kValue ) {
        for (int i = 0; i < 1000; i++) {
            Map<Double, Digit> similarityMap = new HashMap<>();
            ArrayList<Double> similarities = new ArrayList<>();
            for (int j = 0; j < 5000; j++) {
                double similarity = 0;
                for (int m = 0; m < 28; m++) {
                    for (int n = 0; n < 28; n++) {
                            similarity += (trainingImages.get(j).getImageValues()[m][n]-testingImages.get(i).getImageValues()[m][n])*(trainingImages.get(j).getImageValues()[m][n]-testingImages.get(i).getImageValues()[m][n]);
                    }
                }
                similarity = Math.sqrt(similarity);
                similarityMap.put(similarity,trainingImages.get(j));
                similarities.add(similarity);
            }
            Collections.sort(similarities);
            int [] occur = new int [10];
            for (int y = 0; y < 10; y++) {
                occur[y] = 0;
            }
            for (int z = 0; z < kValue; z++) {
                occur[similarityMap.get(similarities.get(z)).getLabel()]++;
            }

            int predict = -1;
            int highVal = -1000;
            for (int b = 0; b < 10; b++) {
                if (occur[b] > highVal) {
                    predict = b;
                    highVal = occur[b];
                }
            }

            testPredictions.put(testingImages.get(i),predict);
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        KNearestNeighbors knn = new KNearestNeighbors();
        knn.readAndSetDigits("trainingimages", true);
        knn.readAndSetLabels("traininglabels", true);
        knn.readAndSetDigits("testimages", false);
        knn.readAndSetLabels("testlabels", false);
        knn.knnClassify(10);
        knn.calculateTestSetAccuracy();
        knn.printConfusionMatrix();
    }
}



